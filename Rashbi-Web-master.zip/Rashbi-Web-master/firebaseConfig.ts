import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'
import { getStorage } from 'firebase/storage'


// Initialize Firebase
const firebaseConfig = {
    apiKey: 'AIzaSyCo2dOwBBWfTXpZD8D9I7PnXJXm3Q4YneM',
    authDomain: 'rashbi-1c5da.firebaseapp.com',
    projectId: 'rashbi-1c5da',
    storageBucket: 'rashbi-1c5da.appspot.com',
    messagingSenderId: '504557552260',
    appId: '1:504557552260:web:7a4d28966cf091d34178d1',
    measurementId: 'G-HCX1VQ1NXD'
  }

  export const FIREBASE_APP = initializeApp(firebaseConfig)
  export const FIRESTORE_DB = getFirestore(FIREBASE_APP)
  export const FIREBASE_AUTH = getAuth (FIREBASE_APP)
  export const STORAGE_CONFIG = getStorage (FIREBASE_APP)