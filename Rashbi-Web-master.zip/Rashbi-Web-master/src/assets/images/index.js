const BackGround = require('./BackGround.png')
const Gmail = require('./Gmail.png')
const Password = require('./Password.png')
const Rashbi = require('./RashbiLogo.png')
const Categories = require('./Categories.png')
const Sub_Categorie = require('./SubCategories.png')

const Link = require('./Link.png')
const Consultation = require('./Consultation.png')
const Requests = require('./Requests.png')
const Setting = require('./Setting.png')
const DailyStudy = require('./dailyStudies.png')
const HomeSlider = require('./homeSlider.png')
const DetailFoam = require('./detailForm.png')
const PopUp = require('./popUpNews.png')
const ScreenBackGround = require('./ScreenBackGround.png')
const LeftArrow = require('./LeftArrow.png')
const RightArrow = require('./RightArrow.png')
const BackArrow = require('./BackArrow.png')
const ForwardArrow = require('./ForwardArrow.png')
const ThreeDot = require('./ThreeDot.png')
const ConsultationActive = require('./ConsultationActive.png')
const DailyStudyActive = require('./DailyStudyActive.png')
const HomeSliderActive = require('./HomeSliderActive.png')
const RequestActive = require('./RequestActive.png')
const SettingActive = require('./SettingActive.png')
const SubCategoriesActive = require('./SubCategoriesActive.png')
const AddIcon = require('./AddIcon.png')
const TrueIcon = require('./TrueIcon.png')
const ProfileImage = require('./ProfileImage.png')
const HomeSliderView = require('./HomeSliderView.png')
const SliderAdd = require('./SliderAdd.png')
const SliderOne = require('./Sliderone.png')
const SliderTwo = require('./SliderTwo.png')
const SliderThree = require('./SliderThree.png')
const Calendar = require('./calendar.png')
const Logout = require('./logout.png')
const Book = require('./book.png')

export const IMAGES = {
    BackGround,
    Gmail,
    Password,
    Rashbi,
    Categories,
    Sub_Categorie,
    Link,
    Consultation,
    Requests,
    Setting,
    DailyStudy,
    HomeSlider,
    DetailFoam,
    PopUp,
    ScreenBackGround,
    LeftArrow,
    RightArrow,
    BackArrow,
    ForwardArrow,
    ThreeDot,
    ConsultationActive,
    DailyStudyActive,
    HomeSliderActive,
    RequestActive,
    SettingActive,
    SubCategoriesActive,
    AddIcon,
    TrueIcon,
    ProfileImage,
    HomeSliderView,
    SliderAdd,
    SliderOne,
    SliderTwo,
    SliderThree,
    Calendar,
    Logout,
    Book,
}