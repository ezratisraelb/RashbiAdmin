import * as ImagePicker from 'expo-image-picker'
import { CommonActions } from '@react-navigation/native'
import * as DocumentPicker from 'expo-document-picker'

export const openGallery = () => {
    return new Promise((resolve, reject) => {
        ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: true,
            aspect: [4, 3],
            quality: 1,
        })
            .then((image) => resolve(image))
            .catch((err) => reject(err))
    })
}

export const pickVideo = () => {
    return new Promise((resolve, reject) => {
        ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Videos,
            allowsEditing: true,
            aspect: [4, 3],
            quality: 1,
        })
            .then((video) => resolve(video))
            .catch((err) => reject(err))
    })
}

export const handleResetStack = (navigation, screenName) => {
    navigation.dispatch(
        CommonActions.reset({
            routes: [{ name: screenName }]
        })
    )
}

export const pickDocument = async () => {
    return new Promise(async (resolve, reject) => {
        let result = await DocumentPicker.getDocumentAsync({ type: ['application/pdf'] })
        if (result) {
            resolve(result?.assets[0])
        } else {
            reject(false)
        }
    })
}

export const textLimit = (text, limit) => {
    if (text?.length >= limit) {
        return `${text?.slice(0, limit)}...`
    } else {
        return text
    }
}
