
import { useState, useMemo, useEffect } from 'react'
import { debounce } from 'lodash'

export default function useDoubleSearch(initialData = [], keyPath, secondaryKeyPath) {
    const [search, setSearch] = useState('')
    const [searchResult, setSearchResult] = useState(initialData)

    const getNestedProperty = (object, keyPath) => {
        const keys = keyPath.split('.')
        let result = object
        for (const key of keys) {
            result = result?.[key]
        }
        return result
    }

    useEffect(() => {
        setSearchResult(initialData)
    }, [initialData])

    const handleSearch = debounce((text) => {
        if (text) {
            setSearch(text)
            const newArray = initialData.filter((item) => {
                const primaryValue = getNestedProperty(item, keyPath)?.toString()?.toLowerCase()
                const secondaryValue = getNestedProperty(item, secondaryKeyPath)?.toString().toLowerCase()

                return primaryValue?.includes(text?.toLowerCase()) || secondaryValue?.includes(text?.toLowerCase())
            })
            setSearchResult(newArray)
        } else {
            setSearch('')
            setSearchResult(initialData)
        }
    }, 50)

    const memorizedResult = useMemo(() => searchResult, [searchResult])

    return [memorizedResult, { search, handleSearch }]
}

