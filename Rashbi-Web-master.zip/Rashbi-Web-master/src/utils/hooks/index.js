import useSearch from './useSearch'
import useDoubleSearch from './useDoubleSearch'
import usePagination from './usePagination'

export {
    useSearch,
    useDoubleSearch,
    usePagination,
}