import React, { useState } from 'react'

export default function usePagination(items, itemsPerPage = 5) {
    const [currentPage, setCurrentPage] = useState(1)

    const totalEntries = items?.length
    const totalPages = Math.ceil(totalEntries / itemsPerPage)

    const moveToPage = (page) => {
        const newPage = Math.max(1, Math.min(page, totalPages))
        setCurrentPage(newPage)
    }

    const moveToNextPage = () => {
        moveToPage(currentPage + 1)
    }

    const moveToPreviousPage = () => {
        moveToPage(currentPage - 1)
    }

    const startItemIndex = (currentPage - 1) * itemsPerPage
    const endItemIndex = Math.min(currentPage * itemsPerPage - 1, totalEntries - 1)

    const onSerialNumber = (index) => {
        return (currentPage - 1) * itemsPerPage + index + 1
    }

    const renderData = items?.slice(startItemIndex, endItemIndex + 1)

    const showingString = `מציג ${startItemIndex + 1} עד ${endItemIndex + 1} מתוך ${items?.length} פריטים`

    return {
        currentPage,
        moveToNextPage,
        moveToPreviousPage,
        showPreviousButton: currentPage === 1,
        showNextButton: currentPage === totalPages,
        startItemIndex,
        endItemIndex,
        getSerialNumber: (x) => onSerialNumber(x),
        renderData: renderData,
        noteString: showingString,
    }
}