import { ImageBackground, StyleSheet, View } from 'react-native'
import { IMAGES } from '../../assets/images'
import { Button, Input, Label } from '../../components'
import { COLOR, TEXT_STYLE, commonStyles, hp } from '../../data/StyleGuides'
import { KEYBOARD_TYPE, SCREEN } from '../../data/enums'
import En from '../../data/locals/En'
import { loginWithEmail } from '../../services/firebaseServices'
import { useState, useEffect } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import { FIREBASE_AUTH } from '../../../firebaseConfig'
import { handleResetStack } from '../../utils/Helper'

const LoginScreen = ({ navigation }) => {
    // admin@gmail.com
    // admin123@
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [loading, setLoading] = useState(false)

    const login = async () => {
        if (email && password) {
            setLoading(true)
            await loginWithEmail(email, password, (data) => {
                setLoading(false)
            })
        }
        else alert(En.noEmptyEmailPassword)
    }

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(FIREBASE_AUTH, (user) => {
            if (user) {
                handleResetStack(navigation, SCREEN.CATEGORIES)
            }
        })
        return unsubscribe
    }, [])


    return (
        <ImageBackground source={IMAGES.BackGround} style={styles.backGroundImage}>
            <View style={styles.container}>
                <Label style={styles.systemAdmin}>{En.systemAdministrator}</Label>
                <Input onChange={(e) => setEmail(e)} placeholder={En.email} style={styles.inputContainer} icon={IMAGES.Gmail} />
                <Input isPassword onChange={(e) => setPassword(e)} keyboard={KEYBOARD_TYPE.NUMERIC} placeholder={En.password} style={styles.inputContainer} icon={IMAGES.Password} imageStyle={styles.iconStyle} />
                <Button
                    text={En.login}
                    isLoading={loading}
                    onPress={() => login()}
                    style={styles.button}
                />
            </View>
        </ImageBackground>
    )
}

export default LoginScreen

const styles = StyleSheet.create({
    backGroundImage: {
        height: '100%',
        width: '100%',
        flex: 1,
        ...commonStyles.center,
    },
    container: {
        height: hp(65),
        width: '40%',
        backgroundColor: COLOR.white,
        borderWidth: hp(0.4),
        borderColor: COLOR.secondary,
        borderRadius: 15,

        // ...commonStyles.center,
    },
    systemAdmin: {
        textAlign: 'center',
        ...TEXT_STYLE.bigTextBold,
        fontWeight: '700',
        paddingVertical: hp(6),
    },
    inputContainer: {
        height: hp(8),
        width: '70%',
        alignSelf: 'center',
        marginVertical: hp(3)
    },
    iconStyle: {
        height: hp(3),
        width: hp(2.3)
    },
    button: {
        height: hp(6),
        width: '27%',
    },
})
