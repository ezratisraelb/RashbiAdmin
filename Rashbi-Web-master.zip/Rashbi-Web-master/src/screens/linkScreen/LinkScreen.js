import { StyleSheet, View } from 'react-native'
import React from 'react'
import { Button, Input, Label, Layout } from '../../components'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { SCREEN } from '../../data/enums'
import En from '../../data/locals/En'

const LinkScreen = ({ navigation }) => {

    return (
        <Layout title={En.links}>

            <Label style={styles.textHeading}>{En.socialLinkForm}</Label>
            <View style={{ flexDirection: 'row-reverse', alignItems: 'center', paddingHorizontal: '5%' }}>
                <Label style={{ paddingHorizontal: '2%' }}>{'כתובת אתר:'}</Label>
                <Input style={styles.inputContainer} placeholder={'כתובת אתר'} />
            </View>
            <View style={{ flexDirection: 'row-reverse', alignItems: 'center', paddingHorizontal: '5%', paddingVertical: '3%' }}>
                <Label style={{ paddingHorizontal: '2%' }}>{'הוסף אייקון:'}</Label>
                <Input style={styles.inputContainers} />
            </View>

            <View style={{ ...commonStyles.justifyView, paddingHorizontal: '5%', paddingTop: '15%' }}>
                <Button text={'אישור'} style={styles.buttonStyle} icon={IMAGES.TrueIcon} onPress={() => navigation.navigate(SCREEN.ADD_LINK)} />
                <Button style={styles.buttonStyle} text={'לְבַטֵל'} buttonColor={COLOR.white} gradient={false} />
            </View>

        </Layout>
    )
}

export default LinkScreen

const styles = StyleSheet.create({
    textHeading: {
        paddingHorizontal: '1%',
        paddingVertical: '1%',
        fontWeight: '700',
    },
    inputContainer: {
        width: '40%',
    },
    inputContainers: {
        width: '20%',
    },
    buttonStyle: {
        width: wp(10),
        ...commonStyles.center,
        height: hp(5)
    },
    secondButton: {
        width: wp(10),
        height: hp(7),
        backgroundColor: COLOR.white,
        borderRadius: hp(5),
        justifyContent: 'center',
        alignItems: 'center'
    }
})