import LinkScreen from './LinkScreen'
export default LinkScreen