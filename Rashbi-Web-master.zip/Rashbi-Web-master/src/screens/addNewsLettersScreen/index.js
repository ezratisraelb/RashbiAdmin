import AddNewsLettersScreen from './AddNewsLettersScreen'
export default AddNewsLettersScreen