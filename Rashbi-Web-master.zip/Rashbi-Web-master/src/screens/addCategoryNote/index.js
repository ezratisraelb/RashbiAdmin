import AddCategoryNote from './AddCategoryNote'
export default AddCategoryNote