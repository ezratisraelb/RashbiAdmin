import ConsultationScreen from './ConsultationScreen'
export default ConsultationScreen