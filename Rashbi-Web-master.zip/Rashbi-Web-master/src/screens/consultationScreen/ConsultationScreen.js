import { ScrollView, StyleSheet, View, ActivityIndicator } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Button, ConsultationView, Input, Label, Layout, ListFooter } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { deleteDocument, getCollectionData } from '../../services/firebaseServices'
import { usePagination, useSearch } from '../../utils/hooks'
import { useIsFocused } from '@react-navigation/native'

const CategoriesScreen = ({ navigation }) => {
    const [consultationData, setConsultationData] = useState([])
    const [loading, setLoading] = useState(false)
    const [consultations, { search, handleSearch }] = useSearch(consultationData, 'fileName')
    const isFocused = useIsFocused()

    const {
        renderData,
        currentPage,
        moveToNextPage,
        moveToPreviousPage,
        showPreviousButton,
        showNextButton,
        noteString,
    } = usePagination(consultations)


    useEffect(() => {
        getConsultations()
    }, [isFocused])

    const getConsultations = async () => {
        setLoading(true)
        const data = await getCollectionData(FIREBASE_COLLECTION.CONSULTATION)
        if (data) {
            setConsultationData(data)
        }
        setLoading(false)
    }

    const getSerialNumber = (index) => {
        const entriesPerPage = 5
        return (currentPage - 1) * entriesPerPage + index + 1
    }

    const handleDeleteItem = (id) => {
        deleteDocument(FIREBASE_COLLECTION.CONSULTATION, id)
        getConsultations()
    }

    return (
        <Layout title={En.consultation}>

            <View style={styles.headerStyle}>

                <Button
                    text={En.addNewProduct}
                    icon={IMAGES.AddIcon}
                    style={styles.buttonStyle}
                    onPress={() => navigation.navigate(SCREEN.ADD_CONSULTATION)}
                />

                <View style={commonStyles.horizontalView}>
                    <Input
                        value={search}
                        onChange={handleSearch}
                        style={styles.inputContainer}
                    />
                    <Label style={{ fontWeight: '700' }}>{En.lookFor}</Label>
                </View>

            </View>


            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
            >
                <View style={styles.container}>
                    <Label style={[styles.headerText, { textAlign: 'left' }]}>{En.operations}</Label>
                    <Label style={[styles.headerText, { width: '37%' }]}>{En.fileType}</Label>
                    <Label style={[styles.headerText, { width: '42%' }]}>{En.files}</Label>
                    <Label style={[styles.headerText, { textAlign: 'right' }]}>{En.serialNumber}</Label>
                </View>

                {loading ? <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />
                    :
                    renderData?.map((item, index) => (
                        <ConsultationView
                            item={item}
                            key={index}
                            number={getSerialNumber(index)}
                            firstHeading={En.edit}
                            secondHeading={En.delete}
                            onFirstPress={() => navigation.navigate(SCREEN.ADD_CONSULTATION, { isEdit: true, data: item })}
                            onSecondPress={() => handleDeleteItem(item?.documentId)}
                        />
                    ))
                }

            </ScrollView>

            <ListFooter
                note={noteString}
                showPreviousButton={showPreviousButton}
                moveToNextPage={moveToNextPage}
                moveToPreviousPage={moveToPreviousPage}
                currentPage={currentPage}
                showNextButton={showNextButton}
            />

        </Layout>
    )
}

export default CategoriesScreen

const styles = StyleSheet.create({
    inputContainer: {
        width: wp('10%'),
        borderRadius: hp(1),
        marginHorizontal: '1%',
        height: hp(5.7),
    },
    headerStyle: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
    },
    headerText: {
        minWidth: '7%',
        fontWeight: '700',
        textAlign: 'center',
    },
    buttonStyle: {
        width: wp(18),
        ...commonStyles.center,
        height: hp(5)
    },
    container: {
        height: hp(6),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.secondary,
        borderRadius: hp(4),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        marginVertical: '1%',
    },
})