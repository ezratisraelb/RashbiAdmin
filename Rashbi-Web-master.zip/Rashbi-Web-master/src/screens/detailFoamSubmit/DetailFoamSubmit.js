import { StyleSheet, View, ScrollView, ActivityIndicator } from 'react-native-web'
import React, { useState, useEffect } from 'react'
import { Button, DropDown, FieldModal, Input, Label, Layout } from '../../components'
import En from '../../data/locals/En'
import { IMAGES } from '../../assets/images'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { filedTypes } from '../../data/DummyData'
import { getDocumentById, saveData } from '../../services/firebaseServices'
import { FIREBASE_COLLECTION, FIREBASE_DOCUMENT, SCREEN } from '../../data/enums'
import { handleResetStack } from '../../utils/Helper'

const DetailFoamSubmit = ({ navigation }) => {
    const [fieldList, setFieldList] = useState([])
    const [showModal, setShowModal] = useState(false)
    const [loading, setLoading] = useState(false)
    const [listLoading, setListLoading] = useState(false)

    useEffect(() => {
        getFormData()
    }, [])

    const getFormData = async () => {
        setListLoading(true)
        const data = await getDocumentById(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.DETAIL_FORM)
        if (data) {
            setFieldList(data?.fields)
        }
        setListLoading(false)
    }


    const onFileTpeChanged = (value, index) => {
        let array = [...fieldList]
        array[index].type = value
        setFieldList(array)
    }

    function generateUniqueId() {
        const timestamp = new Date().getTime()
        const uniqueId = `id_${timestamp}`

        return uniqueId
    }

    const onTextChange = (value, index) => {
        let array = [...fieldList]
        array[index].fieldName = value
        setFieldList(array)
    }

    const onAddFiled = (x) => {
        let array = [...fieldList]
        array.push({ id: generateUniqueId(), type: 'optional', fieldName: x })
        setFieldList(array)
    }

    const saveFormData = async () => {
        setLoading(true)
        const formattedData = { fields: fieldList }
        await saveData(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.DETAIL_FORM, formattedData)
        setLoading(false)
        handleResetStack(navigation, SCREEN.DETAIL_FOAM)
    }


    return (
        <Layout title={En.detailForm}>
            <View style={styles.contentStyle}>

                <View style={styles.header}>
                    <Button
                        text={En.addField}
                        icon={IMAGES.AddIcon}
                        style={styles.buttonStyle}
                        onPress={() => setShowModal(true)}
                    />
                    <Label style={styles.textBold}>{En.editFoam}</Label>
                </View>

                <ScrollView
                    bounces={false}
                    overScrollMode='never'
                    showsVerticalScrollIndicator={false}
                >
                    {listLoading ?
                        <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />
                        :
                        fieldList?.map(({ type, fieldName }, index) => (
                            <View style={styles.filedContainer} key={index}>
                                <Label style={styles.filedText}>{En.fileName}</Label>
                                <Input
                                    value={fieldName}
                                    style={styles.inputStyle}
                                    onChange={(x) => onTextChange(x, index)}
                                />
                                <DropDown
                                    value={type}
                                    data={filedTypes}
                                    onChange={(x) => onFileTpeChanged(x, index)}
                                    style={styles.dropDownStyle}
                                />
                            </View>
                        ))
                    }
                </ScrollView>

            </View>
            <Button
                text={En.done}
                isLoading={loading}
                icon={IMAGES.TrueIcon}
                style={styles.button}
                onPress={() => saveFormData()}
                containerStyle={styles.buttonContainer}
            />
            <FieldModal
                visible={showModal}
                setVisible={setShowModal}
                onDonePress={onAddFiled}
            />
        </Layout>
    )
}

export default DetailFoamSubmit

const styles = StyleSheet.create({
    buttonStyle: {
        height: hp(5),
        width: wp(18),
        marginTop: 0,
        marginBottom: 0,
        margin: 0,
        marginVertical: 0,
        ...commonStyles.center,
    },
    header: {
        ...commonStyles.justifyView_m1,
    },
    contentStyle: {
        flex: 1,
        paddingHorizontal: '3%',
    },
    textBold: {
        fontWeight: '700',
    },
    filedText: {
        fontWeight: '500',
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: '5%',
        paddingTop: hp(1),
        backgroundColor: 'red',
    },
    filedContainer: {
        ...commonStyles.horizontalView_m1,
        flexDirection: 'row-reverse',
    },
    inputStyle: {
        width: wp(25),
        marginHorizontal: wp(1),
    },
    dropDownStyle: {
        width: wp(10),
    },
    button: {
        height: hp(6),
        width: '100%',
        borderRadius: hp(4),
    },
    buttonContainer: {
        width: wp(13),
        marginTop: hp(2),
        position: 'absolute',
        bottom: hp(2),
        left: '3%',
    },
})