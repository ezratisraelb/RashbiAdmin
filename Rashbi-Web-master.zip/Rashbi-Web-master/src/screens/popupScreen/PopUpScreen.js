import { StyleSheet, View, ScrollView } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Button, ImagePicker, VideoPicker, Input, Label, Layout } from '../../components'
import En from '../../data/locals/En'
import { hp, wp } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { getDocumentById, saveData, uploadImage } from '../../services/firebaseServices'
import { FIREBASE_COLLECTION, FIREBASE_DOCUMENT, FIREBASE_STORAGE } from '../../data/enums'

const PopUpScreen = () => {
  const [image, setImage] = useState('')
  const [video, setVideo] = useState('')
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchPopupData()
  }, [])


  const fetchPopupData = async () => {
    const data = await getDocumentById(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.POPUP)
    if (data) {
      setImage(data?.image)
      setVideo(data?.video)
      setText(data?.message)
    }
  }

  const handleUpdateContent = async () => {
    if (text) {
      setLoading(true)
      let imageUrl = ''
      let videoUrl = ''

      if (image) {
        imageUrl = image

        if (!imageUrl?.includes('https:') && !imageUrl?.includes('http:')) {
          imageUrl = await uploadImage(image, FIREBASE_STORAGE.POPUP)
          if (imageUrl === 'false') {
            alert(En.somethingWentWrong)
            return
          }
        }
      }

      if (video) {
        videoUrl = video
        if (!videoUrl?.includes('https:') && !videoUrl?.includes('http:')) {
          videoUrl = await uploadImage(video, FIREBASE_STORAGE.POPUP)
          if (videoUrl === 'false') {
            alert(En.somethingWentWrong)
            return
          }
        }
      }

      const formattedData = {
        message: text,
        image: imageUrl,
        video: videoUrl,
      }

      await saveData(FIREBASE_COLLECTION.APP_CONFIG, FIREBASE_DOCUMENT.POPUP, formattedData)
      fetchPopupData()
      setLoading(false)

    } else {
      alert(En.fillDataError)
    }
  }


  return (
    <Layout title={En.popUpNews}>
      <ScrollView
        bounces={false}
        overScrollMode='never'
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentContainer}>
          <Label style={styles.titleStyle}>{En.newsPopupForm}</Label>

          <View style={styles.pickerContainer}>
            <View style={styles.reverseView}>
              <Label style={styles.heading}>{En.video}:</Label>
              <VideoPicker
                value={video}
                onChange={setVideo}
                style={styles.pickerView}
              />
            </View>

            <View style={styles.reverseView}>
              <Label style={styles.heading}>{En.image}:</Label>
              <ImagePicker
                text={En.uploadImage}
                value={image}
                onChange={setImage}
                style={styles.pickerView}
              />
            </View>
          </View>

          <View style={styles.reverseView}>
            <Label style={styles.inputHeading}>{En.text}</Label>
            <Input
              multiline
              value={text}
              onChange={setText}
              style={styles.inputStyle}
            />
          </View>

          <Button
            text={En.done}
            isLoading={loading}
            style={styles.buttonStyle}
            icon={IMAGES.TrueIcon}
            containerStyle={styles.buttonContainer}
            onPress={handleUpdateContent}
          />

        </View>
      </ScrollView>
    </Layout>
  )
}

export default PopUpScreen

const styles = StyleSheet.create({
  contentContainer: {
    paddingHorizontal: '5%',
  },
  reverseView: {
    flexDirection: 'row-reverse',
  },
  pickerContainer: {
    flexDirection: 'row-reverse',
    marginVertical: hp(2),
  },
  pickerView: {
    height: hp(25),
    width: wp(20),
  },
  inputHeading: {
    fontWeight: '700',
    marginLeft: wp(1.3),
    marginRight: wp(0.5),
    marginTop: hp(1),
  },
  inputStyle: {
    height: hp(26),
    width: wp(46.1),
  },
  heading: {
    fontWeight: '700',
    marginHorizontal: wp(1.3),
    marginTop: hp(1),
  },
  titleStyle: {
    fontWeight: '700',
    marginVertical: hp(2),
  },
  buttonStyle: {
    height: hp(5),
    width: '100%',
  },
  buttonContainer: {
    width: wp(10),
  },
})