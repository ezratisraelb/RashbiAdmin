import SettingScreen from './SettingScreen'
export default SettingScreen