import { StyleSheet, View } from 'react-native'
import React, { useState } from 'react'
import { Button, Label, Layout, ProfileImagePicker } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'

const SettingScreen = () => {
  const [image, setImage] = useState('')
  return (
    <Layout title={En.settings}>
      <Label style={{ fontWeight: '700', paddingHorizontal: '3%', paddingVertical: '3%' }}>{En.settingFoam}</Label>
      <View style={{ flexDirection: 'row-reverse' }}>
        <Label style={{ fontWeight: '700', paddingRight: '5%', paddingLeft: '2%' }}>{En.administrator}</Label>
        <ProfileImagePicker buttonStyle={styles.imageButton} buttonText={En.change} value={image} onChange={setImage} />
      </View>
      <View style={{ ...commonStyles.justifyView, paddingHorizontal: '5%' }}>
        <Button text={En.done} style={styles.buttonStyle} icon={IMAGES.TrueIcon} />
        <Button style={styles.buttonStyle} text={En.cancel} buttonColor={COLOR.white} gradient={false} />
      </View>
    </Layout>
  )
}

export default SettingScreen

const styles = StyleSheet.create({
  imageButton: {
    width: '30%',
    // backgroundColor:'red'
  },
  buttonStyle: {
    width: wp(10),
    ...commonStyles.center,
    height: hp(5)
  },
})