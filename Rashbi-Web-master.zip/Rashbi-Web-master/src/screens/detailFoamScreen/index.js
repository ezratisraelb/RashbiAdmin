import DetailFoamScreen from './DetailFoamScreen'
export default DetailFoamScreen