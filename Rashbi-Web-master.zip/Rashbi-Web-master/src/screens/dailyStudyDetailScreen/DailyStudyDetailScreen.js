import { Image, ScrollView, StyleSheet, View } from 'react-native'
import React, { useState } from 'react'
import { Button, ImagePicker, Input, Label, Layout, Pressable } from '../../components'
import En from '../../data/locals/En'
import { hp, wp, commonStyles, COLOR } from '../../data/StyleGuides'
import { FIREBASE_STORAGE, FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { Calendar, LocaleConfig } from 'react-native-calendars'
import moment from 'moment'
import { IMAGES } from '../../assets/images'
import * as DocumentPicker from 'expo-document-picker'
import { addDocument, saveData, uploadImage } from '../../services/firebaseServices'
import { handleResetStack } from '../../utils/Helper'

const DailyStudyDetailScreen = ({ route, navigation }) => {

    const editdata = route?.params?.editItem
    const isPdf = route?.params?.isPDF


    const INITIAL_DATE = moment(new Date()).format('YYYY-MM-DD')
    LocaleConfig.locales['en'] = {
        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        dayNamesShort: ['Sun', 'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat'],
        today: 'Today'
    }

    LocaleConfig.defaultLocale = 'en'



    const [date, setdate] = useState(editdata?.data || INITIAL_DATE)
    const [showCalander, setshowCalander] = useState(false)
    const [textContent, settextContent] = useState(editdata?.text || '')
    const [title, settitle] = useState(editdata?.title || '')
    const [image, setImage] = useState(editdata?.image || '')
    const [pdf, setpdf] = useState()
    const [loading, setloading] = useState(false)

    const pickDocument = async () => {
        let result = await DocumentPicker.getDocumentAsync({ type: ['application/pdf'] })
        setpdf(result)
    }


    const uploadDailyStudy = async () => {
        setloading(true)
        if (isPdf) {
            let imageUrl
            let pdfUrl

            if (editdata?.pdf.includes('https')) {
                pdfUrl = editdata?.pdf

            }
            else {
                pdfUrl = await uploadImage(pdf?.assets[0]?.uri, FIREBASE_STORAGE.DAILY_STUDIES_PDF)

            }

            if (editdata?.image.includes('https')) {
                imageUrl = editdata?.image

            }
            else {
                imageUrl = await uploadImage(image, FIREBASE_STORAGE.DAILY_STUDIES_PDF)

            }

            let data = {
                date: date,
                text: textContent,
                title: title,
                image: imageUrl,
                pdf: pdfUrl
            }

            if (editdata) {
                await saveData(FIREBASE_COLLECTION.DAILY_STUDY, editdata?.documentId, data)
            }
            else await addDocument(FIREBASE_COLLECTION.DAILY_STUDY, data)
            handleResetStack(navigation, SCREEN.DAILY_STUDY)
            setloading(false)

        }
        else {

            if (pdf) {


                if (title != '' && image && pdf && date) {
                    let imageUrl = await uploadImage(image, FIREBASE_STORAGE.DAILY_STUDIES_PDF)
                    let pdfUrl = await uploadImage(pdf?.assets[0]?.uri, FIREBASE_STORAGE.DAILY_STUDIES_PDF)


                    let data = {
                        date: date,
                        text: textContent,
                        title: title,
                        image: imageUrl,
                        pdf: pdfUrl
                    }

                    await addDocument(FIREBASE_COLLECTION.DAILY_STUDY, data)
                    setloading(false)
                    handleResetStack(navigation, SCREEN.DAILY_STUDY)

                }
                else {
                    alert(En.fillDataError)
                    setloading(false)
                }
            }
            else {
                if (title != '' && image && textContent != '' && date) {

                    let imageUrl
                    if (editdata?.image.includes('https')) {
                        imageUrl = editdata?.image

                    }
                    else {
                        imageUrl = await uploadImage(image, FIREBASE_STORAGE.DAILY_STUDIES)
                    }

                    let data = {
                        date: date,
                        text: textContent,
                        title: title,
                        image: imageUrl
                    }



                    if (editdata) {
                        await saveData(FIREBASE_COLLECTION.DAILY_STUDY, editdata?.documentId, data)
                    }
                    else await addDocument(FIREBASE_COLLECTION.DAILY_STUDY, data)

                    setloading(false)
                    handleResetStack(navigation, SCREEN.DAILY_STUDY)
                }
                else {
                    alert(En.fillDataError)
                    setloading(false)
                }
            }
        }

    }



    return (
        <Layout title={En.dailyStudies}>
            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
            >
                <View style={{ flexDirection: 'row-reverse', paddingVertical: hp(1), alignItems: 'center' }}>
                    <Label style={{ paddingRight: '3%', fontWeight: '700' }}>{En.dailyStudyFoam}</Label>

                    <View style={{ flexDirection: 'row', paddingRight: '50%', alignItems: 'center' }}>
                        <View style={[styles.container, { justifyContent: 'space-between' }]}>
                            <Pressable onPress={() => setshowCalander(!showCalander)}>
                                <Image style={[styles.iconStyle]} source={IMAGES.Calendar} resizeMode='contain' />
                            </Pressable>
                            <Label style={{ fontWeight: '700' }}>{date}</Label>

                        </View>
                        <Label style={{ fontWeight: '700', paddingHorizontal: '2%' }}>{En.addMore}</Label>
                    </View>


                </View>
                {
                    showCalander &&

                    <View style={{ width: wp(15), marginLeft: wp(9.3), zIndex: 1000, position: 'absolute', marginTop: hp(10) }}>
                        <Calendar
                            current={INITIAL_DATE}
                            firstDay={1}
                            showWeekNumbers={false}
                            disableAllTouchEventsForDisabledDays={false}
                            onDayPress={(day) => { setdate(day.dateString), setshowCalander(false) }}
                            enableSwipeMonths={true}
                            minDate={INITIAL_DATE}
                            style={{ marginBottom: hp(1), borderWidth: 1, borderColor: COLOR.secondary, borderRadius: 10 }}
                            monthFormat={'MMMM, yyyy'}
                            theme={styles.calenderTheme}
                        />
                    </View>
                }
                {
                    !(pdf || isPdf) && (
                        <View style={{ flexDirection: 'row-reverse' }}>
                            <Label style={{ fontWeight: '700', paddingRight: hp(5) }}>{En.studyContent}</Label>
                            <Input value={textContent} onChange={(e) => settextContent(e)} multiline style={styles.inputView} />
                        </View>
                    )
                }




                <View style={{ flexDirection: 'row-reverse', alignItems: 'center' }}>
                    <Label style={{ fontWeight: '700', paddingRight: hp(5) }}>{En.fileName}</Label>
                    <Input value={title} onChange={(e) => settitle(e)} style={{ width: wp(15), marginRight: hp(2) }} />
                </View>
                <View style={{ flexDirection: 'row-reverse', alignItems: 'center' }}>
                    <Label style={{ fontWeight: '700', paddingRight: hp(5) }}>{En.addMore}</Label>
                    <ImagePicker value={image} onChange={setImage} text={En.uploadImage} style={{ height: hp(19), width: wp(20), marginRight: hp(2) }} />
                </View>
                <View style={styles.footerButtons}>
                    <Button
                        text={pdf ? pdf?.assets[0]?.name : En.uploadPDF}
                        style={styles.buttonStyle}
                        containerStyle={styles.button}
                        onPress={() => pickDocument()}
                    />
                    <Button
                        text={En.uploadFile}
                        style={styles.buttonStyle}
                        containerStyle={styles.button}
                        isLoading={loading}
                        onPress={() => uploadDailyStudy()}
                    />
                </View>
            </ScrollView>

        </Layout>
    )
}

export default DailyStudyDetailScreen

const styles = StyleSheet.create({
    inputcontainer: {
        width: wp(15)
    },
    inputView: {
        height: hp(18),
        width: wp(30),
        marginRight: hp(1)
    },
    buttonStyle: {
        height: hp(5),
        width: wp(15),
    },
    footerButtons: {
        ...commonStyles.horizontalView_m1,
        justifyContent: 'flex-end',
        paddingRight: hp(10)
    },
    button: {
        marginHorizontal: '2%',
    },
    calenderTheme: {
        'stylesheet.calendar.header': {
            week: {
                marginTop: hp(1),
                paddingTop: hp(0.5),
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'space-between',
                borderBottomWidth: 0.5,
                borderTopWidth: 0.5,
                borderColor: COLOR.red,
            },
            header: {
                height: hp(5),
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'space-between',

            },
        },
        todayTextColor: COLOR.white,
        todayBackgroundColor: COLOR.red,
        dayTextColor: COLOR.black,

        textDayFontSize: 12,
        textMonthFontSize: hp(1.75),
        textDayHeaderFontSize: 12,
        monthTextColor: COLOR.red,

    },

    container: {
        height: hp(6.6),
        width: wp(15),
        borderRadius: hp(1.8),
        marginVertical: hp(1),
        backgroundColor: COLOR.white,
        ...commonStyles.horizontalView,
        ...commonStyles.shadow_3,
        borderWidth: 1,
        borderColor: COLOR.secondary,
        overflow: 'hidden',
        paddingEnd: '5%',
    },
    iconStyle: {
        height: hp(3),
        width: hp(3),
        marginLeft: wp(1),
    },
})