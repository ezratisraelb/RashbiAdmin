import DailyStudyScreen from './DailyStudyScreen'
export default DailyStudyScreen