import React, { useEffect, useState } from 'react'
import { ScrollView, StyleSheet, View, ActivityIndicator } from 'react-native'
import { IMAGES } from '../../assets/images'
import { Button, CategoriesView, Input, Label, Layout, ListFooter } from '../../components'
import { COLOR, commonStyles, hp, wp } from '../../data/StyleGuides'
import { FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import En from '../../data/locals/En'
import { deleteDocument, getCollectionData } from '../../services/firebaseServices'
import { useIsFocused } from '@react-navigation/native'
import { usePagination, useSearch } from '../../utils/hooks'

const DailyStudyScreen = ({ navigation }) => {
    const [dailyStudies, setDailyStudies] = useState([])
    const [loading, setLoading] = useState(true)
    const isFocused = useIsFocused()

    const [dailyStudiesData, { search, handleSearch }] = useSearch(dailyStudies, 'title')

    const {
        renderData,
        currentPage,
        moveToNextPage,
        moveToPreviousPage,
        showPreviousButton,
        showNextButton,
        noteString,
    } = usePagination(dailyStudiesData)

    useEffect(() => {
        getDailyStudies()
    }, [isFocused])

    const getDailyStudies = async () => {
        let data = await getCollectionData(FIREBASE_COLLECTION.DAILY_STUDY)
        setDailyStudies(data)
        setLoading(false)
    }

    const getSerialNumber = (index) => {
        const entriesPerPage = 5
        return (currentPage - 1) * entriesPerPage + index + 1
    }

    const handleEditItem = (item) => {
        navigation.navigate(SCREEN.DAILY_DETAIL, { editItem: item, isPDF: item?.pdf ? true : false })
    }

    const handleDeleteItem = (id) => {
        deleteDocument(FIREBASE_COLLECTION.DAILY_STUDY, id)
        getDailyStudies()
    }

    return (
        <Layout title={En.dailyStudies}>
            <View style={styles.headerStyle}>
                <Button
                    style={styles.buttonStyle} text={En.addFile}
                    icon={IMAGES.AddIcon}
                    onPress={() => navigation.navigate(SCREEN.DAILY_DETAIL)}
                />
                <View style={commonStyles.horizontalView}>
                    <Input
                        value={search}
                        onChange={handleSearch}
                        style={styles.inputContainer}
                    />
                    <Label style={{ fontWeight: '700' }}>{En.lookFor}</Label>
                </View>

            </View>
            <View style={styles.container}>
                <Label style={{ fontWeight: '700' }}>{En.operations}</Label>
                <Label style={{ fontWeight: '700' }}>{En.dailyStudies}</Label>
                <Label style={{ fontWeight: '700' }}>{En.serialNumber}</Label>
            </View>
            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
                style={{ marginBottom: hp(2) }}
            >

                {loading && <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />}

                <View style={styles.categorView}>
                    {renderData?.map((item, index) => (
                        <CategoriesView
                            text={item?.title}
                            key={index}
                            number={getSerialNumber(index)}
                            onFirstPress={() => handleEditItem(item)}
                            onSecondPress={() => handleDeleteItem(item?.documentId)}
                            firstHeading={En.edit}
                            secondHeading={En.delete}
                        />
                    ))}
                </View>


            </ScrollView>

            <ListFooter
                note={noteString}
                showPreviousButton={showPreviousButton}
                moveToNextPage={moveToNextPage}
                moveToPreviousPage={moveToPreviousPage}
                currentPage={currentPage}
                showNextButton={showNextButton}
            />




        </Layout>
    )
}

export default DailyStudyScreen

const styles = StyleSheet.create({
    inputContainer: {
        width: wp('10%'),
        borderRadius: hp(1),
        marginHorizontal: '1%',
        height: hp(5.7),
    },
    headerStyle: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
    },
    buttonStyle: {
        width: wp(18),
        ...commonStyles.center,
        height: hp(5)
    },
    container: {
        height: hp(6),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.secondary,
        borderRadius: hp(4),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        marginVertical: '1%',
    },
    arrowButtons: {
        height: hp(5),
        width: hp(5),
        borderRadius: hp(3),
        backgroundColor: COLOR.secondary,
        ...commonStyles.center,
    },
    arrowStyle: {
        height: '50%',
        width: '90%',
    },
    buttonContainer: {
        ...commonStyles.horizontalView,
        marginBottom: hp(3),
        marginLeft: '5%',
    },
})