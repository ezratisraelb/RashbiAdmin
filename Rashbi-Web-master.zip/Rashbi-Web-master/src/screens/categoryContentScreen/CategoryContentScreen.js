import { ScrollView, StyleSheet, View, ActivityIndicator } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Button, CategoriesView, Input, Label, Layout, ListFooter } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { useDoubleSearch, usePagination, useSearch } from '../../utils/hooks'
import { deleteDocument, getCollectionData } from '../../services/firebaseServices'
import { useIsFocused } from '@react-navigation/native'
import { textLimit } from '../../utils/Helper'

const CategoryContentScreen = ({ navigation, route }) => {
    const documentId = route?.params?.id
    const [loading, setLoading] = useState(false)
    const [subContent, setSubContent] = useState([])
    // const [subContentData, { search, handleSearch }] = useDoubleSearch(subContent, 'studyName', 'studyName')
    const [subContentData, { search, handleSearch }] = useSearch(subContent, 'studyName')
    const isFocused = useIsFocused()
    const {
        renderData,
        currentPage,
        moveToNextPage,
        moveToPreviousPage,
        showPreviousButton,
        showNextButton,
        noteString,
    } = usePagination(subContentData)
    useEffect(() => {
        getSubCategoriesData()
    }, [isFocused])
    const getSubCategoriesData = async () => {
        setLoading(true)
        const data = await getCollectionData(FIREBASE_COLLECTION.CATEGORY_CONTENT)
        const selectedDocuments = data.filter(x => x?.parentId == documentId)
        setSubContent(selectedDocuments)
        setLoading(false)
    }
    const getSerialNumber = (index) => {
        const entriesPerPage = 5
        return (currentPage - 1) * entriesPerPage + index + 1
    }
    const handleDeleteItem = (id) => {
        deleteDocument(FIREBASE_COLLECTION.CATEGORY_CONTENT, id)
        getSubCategoriesData()
    }
    return (
        <Layout title={En.subCategoriesContent}>
            <View style={styles.headerStyle}>
                <Button
                    style={styles.buttonStyle}
                    text={En.addNewContent}
                    icon={IMAGES.AddIcon}
                    onPress={() => navigation.navigate(SCREEN.ADD_CATEGORIES_NOTE, { parentId: documentId })}
                />
                <View style={commonStyles.horizontalView}>
                    <Input
                        value={search}
                        onChange={handleSearch}
                        style={styles.inputContainer}
                    />
                    <Label style={{ fontWeight: '700' }}>{En.lookFor}</Label>
                </View>
            </View>
            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
            >
                <View style={styles.container}>
                    <Label style={{ fontWeight: '700' }}>{En.operations}</Label>
                    <Label style={{ fontWeight: '700' }}>{En.subCategoryName}</Label>
                    <Label style={{ fontWeight: '700' }}>.{En.serialNumber}</Label>
                </View>
                <View style={styles.categorView}>
                    {loading ? <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />
                        :
                        renderData?.map((item, index) => (
                            <CategoriesView
                                text={item?.studyName}
                                key={index}
                                number={getSerialNumber(index)}
                                firstHeading={En.edit}
                                secondHeading={En.delete}
                                onFirstPress={() => navigation.navigate(SCREEN.ADD_CATEGORIES_NOTE, { isEdit: true, parentId: documentId, data: item })}
                                onSecondPress={() => handleDeleteItem(item?.documentId)}
                            />
                        ))}
                </View>
            </ScrollView>
            <ListFooter
                note={noteString}
                showPreviousButton={showPreviousButton}
                moveToNextPage={moveToNextPage}
                moveToPreviousPage={moveToPreviousPage}
                currentPage={currentPage}
                showNextButton={showNextButton}
            />
        </Layout>
    )
}
export default CategoryContentScreen
const styles = StyleSheet.create({
    inputContainer: {
        width: wp('10%'),
        borderRadius: hp(1),
        marginHorizontal: '1%',
        height: hp(5.7),
    },
    headerStyle: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
    },
    buttonStyle: {
        width: wp(20),
        ...commonStyles.center,
        height: hp(5)
    },
    container: {
        height: hp(6),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.secondary,
        borderRadius: hp(4),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        marginVertical: '1%',
    },
})