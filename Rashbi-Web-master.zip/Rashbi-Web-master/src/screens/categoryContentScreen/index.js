import CategoryContentScreen from './CategoryContentScreen'
export default CategoryContentScreen