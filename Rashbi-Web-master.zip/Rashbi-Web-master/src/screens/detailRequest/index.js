import DetailRequest from './DetailRequest'
export default DetailRequest