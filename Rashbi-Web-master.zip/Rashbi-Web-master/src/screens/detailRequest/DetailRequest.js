import { ScrollView, StyleSheet, View } from 'react-native'
import React, { useState } from 'react'
import { Button, If, Label, Layout } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, COLOR, wp } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { handleResetStack } from '../../utils/Helper'
import { FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { saveData } from '../../services/firebaseServices'

const DetailRequest = ({ route, navigation }) => {
    const paramData = route?.params?.data
    const payment = paramData?.payment
    // const approved = paramData?.approved
    // const [loading, setLoading] = useState(false)

    // const handleApproveRequest = async () => {
    //     setLoading(true)
    //     const formattedData = {
    //         ...paramData,
    //         approved: true,
    //     }
    //     await saveData(FIREBASE_COLLECTION.REQUEST, paramData.documentId, formattedData)
    //     resetData()
    // }

    // const resetData = () => {
    //     setLoading(false)
    //     handleResetStack(navigation, SCREEN.REQUEST)
    // }

    const FieldView = ({ fieldName, value }) => (
        <View style={styles.main}>
            <Label style={styles.boldText}>{fieldName}:</Label>
            <Label style={styles.valueText}>{value}</Label>
        </View>
    )

    const convertAmount = (amount) => {
        if (amount) {
            const { currency_code, value } = amount
            return `${currency_code} ${value}`
        }
    }

    return (
        <Layout title={En.requests}>
            <View style={{ flex: 1, }}>
                <ScrollView
                    bounces={false}
                    overScrollMode='never'
                    showsVerticalScrollIndicator={false}
                >
                    <Label style={styles.title}>{En.detailRequest}</Label>
                    {/* Show userInfo */}
                    {Object?.entries(paramData?.userInfo)?.map(([fieldName, value]) => (
                        <FieldView fieldName={fieldName} value={value} />
                    ))}

                    {/* Show payment data */}
                    <If condition={payment}>
                        <Label style={styles.title}>{En.paymentDetails}</Label>
                        <FieldView fieldName={En.accountId} value={payment?.payer?.account_id} />
                        <FieldView fieldName={En.name} value={`${payment?.payer?.given_name} ${payment?.payer?.surname}`} />
                        <FieldView fieldName={En.email} value={payment?.payer?.email_address} />
                        <FieldView fieldName={En.address} value={payment?.payer?.address_line_1} />
                        <FieldView fieldName={En.postalCode} value={payment?.payer?.postal_code} />


                        <FieldView fieldName={En.paypalFee} value={convertAmount(payment?.amount?.paypal_fee)} />
                        <FieldView fieldName={En.grossAmount} value={convertAmount(payment?.amount?.gross_amount)} />
                        <FieldView fieldName={En.NetAmount} value={convertAmount(payment?.amount?.net_amount)} />
                        <FieldView fieldName={En.total} value={convertAmount(payment?.amount?.total)} />
                    </If>

                </ScrollView>
            </View>
            {/* <View style={styles.buttonContainer}>
                <Button
                    text={approved ? En.approved : En.approve}
                    gradient={!approved}
                    isLoading={loading}
                    icon={approved && IMAGES.TrueIcon}
                    style={[styles.buttonStyle, approved && { backgroundColor: COLOR.white }]}
                    textStyle={approved && { color: COLOR.green }}
                    onPress={() => !approved && handleApproveRequest()}
                />
                <Button
                    gradient={false}
                    text={En.cancel}
                    buttonColor={COLOR.white}
                    style={styles.buttonStyle}
                    onPress={() => resetData()}
                />
            </View> */}
        </Layout>
    )
}

export default DetailRequest

const styles = StyleSheet.create({
    main: {
        flexDirection: 'row-reverse',
        // paddingHorizontal: '10%',
        paddingHorizontal: '4%',
        paddingVertical: '1%',
    },
    title: {
        fontWeight: '700',
        paddingHorizontal: '3%',
        paddingVertical: '3%',
        textAlign: 'right',
    },
    buttonStyle: {
        width: wp(10),
        ...commonStyles.center,
        height: hp(5)
    },
    buttonContainer: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
        marginBottom: hp(2),
    },
    boldText: {
        width: wp(10),
        fontWeight: '700',
        textAlign: 'right',
        // backgroundColor: 'lightblue',
    },
    valueText: {
        paddingEnd: '5%',
    },
})