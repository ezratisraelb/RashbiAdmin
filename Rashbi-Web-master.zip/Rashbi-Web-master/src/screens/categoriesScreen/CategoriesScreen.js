import { ScrollView, StyleSheet, View, ActivityIndicator } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Button, CategoriesView, Input, Label, Layout, ListFooter } from '../../components'
import En from '../../data/locals/En'
import { hp, commonStyles, wp, COLOR } from '../../data/StyleGuides'
import { IMAGES } from '../../assets/images'
import { FIREBASE_COLLECTION, SCREEN } from '../../data/enums'
import { deleteDocument, getCollectionData } from '../../services/firebaseServices'
import { usePagination, useSearch } from '../../utils/hooks'
import { useIsFocused } from '@react-navigation/native'

const CategoriesScreen = ({ navigation }) => {
    const [categories, setCategories] = useState([])
    const [loading, setLoading] = useState(false)
    const [categoriesData, { search, handleSearch }] = useSearch(categories, 'title')
    const isFocused = useIsFocused()

    const {
        renderData,
        currentPage,
        moveToNextPage,
        moveToPreviousPage,
        showPreviousButton,
        showNextButton,
        noteString,
    } = usePagination(categoriesData)

    useEffect(() => {
        getCategoriesData()
    }, [isFocused])

    const getCategoriesData = async () => {
        setLoading(true)
        const data = await getCollectionData(FIREBASE_COLLECTION.CATEGORIES)
        if (data) {
            setCategories(data)
        }
        setLoading(false)
    }

    const getSerialNumber = (index) => {
        const entriesPerPage = 5
        return (currentPage - 1) * entriesPerPage + index + 1
    }

    const handleDeleteItem = (id) => {
        deleteDocument(FIREBASE_COLLECTION.CATEGORIES, id)
        getCategoriesData()
    }

    return (
        <Layout title={En.categories}>

            <View style={styles.headerStyle}>

                <Button
                    style={styles.buttonStyle} text={En.addNewCategories}
                    icon={IMAGES.AddIcon}
                    onPress={() => navigation.navigate(SCREEN.ADD_CATEGORIES)}
                />

                <View style={commonStyles.horizontalView}>
                    <Input value={search} onChange={handleSearch} style={styles.inputContainer} />
                    <Label style={{ fontWeight: '700' }}>{En.lookFor}</Label>
                </View>
            </View>


            <ScrollView
                bounces={false}
                overScrollMode='never'
                showsVerticalScrollIndicator={false}
            >
                <View style={styles.container}>
                    <Label style={{ fontWeight: '700' }}>{En.operations}</Label>
                    <Label style={{ fontWeight: '700' }}>{En.category}</Label>
                    <Label style={{ fontWeight: '700' }}>.{En.serialNumber}</Label>
                </View>

                {loading ? <ActivityIndicator size={35} color={COLOR.red} style={{ marginTop: hp(2) }} />
                    :
                    renderData?.map((item, index) => (
                        <CategoriesView
                            text={item?.title}
                            key={index}
                            number={getSerialNumber(index)}
                            firstHeading={En.edit}
                            // secondHeading={En.subCategories}
                            thirdHeading={En.delete}
                            onFirstPress={() => navigation.navigate(SCREEN.ADD_CATEGORIES, { isEdit: true, data: item })}
                            onThirdPress={() => handleDeleteItem(item?.documentId)}
                        />
                    ))
                }

            </ScrollView>

            <ListFooter
                note={noteString}
                showPreviousButton={showPreviousButton}
                moveToNextPage={moveToNextPage}
                moveToPreviousPage={moveToPreviousPage}
                currentPage={currentPage}
                showNextButton={showNextButton}
            />

        </Layout>
    )
}

export default CategoriesScreen

const styles = StyleSheet.create({
    inputContainer: {
        width: wp('10%'),
        borderRadius: hp(1),
        marginHorizontal: '1%',
        height: hp(5.7),
    },
    headerStyle: {
        ...commonStyles.justifyView,
        paddingHorizontal: '5%',
    },
    buttonStyle: {
        width: wp(18),
        ...commonStyles.center,
        height: hp(5)
    },
    container: {
        height: hp(6),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.secondary,
        borderRadius: hp(4),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        marginVertical: '1%',
    },
})