import LinkDetailScreen from './LinkDetailScreen'
export default LinkDetailScreen