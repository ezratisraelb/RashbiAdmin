import React from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { SCREEN } from '../data/enums'
import { LoginScreen, CategoriesScreen, SubCategoriesScreen, ConsultationScreen, DailyStudyScreen, DetailFoamScreen, HomeSliderScreen, PopUpScreen, RequestScreen, AddCategoryScreen, AddSubCategoriesScreen, AddCategoryNote, AddLinkScreen, LinkDetailScreen, AddConsultationScreen, DetailRequest, DailyStudyDetailScreen, DetailFoamSubmit, BooksListScreen, AddBookScreen, CategoryContentScreen, NewsLettersScreen, AddNewsLettersScreen } from '../screens'

const Stack = createNativeStackNavigator()

const screenOptionStyle = {
    headerShown: false,
}

const RootNavigator = () => {

    return (
        <NavigationContainer linking={{
            config: {
                screens: {
                    [SCREEN.LOGIN]: 'Login/',
                    [SCREEN.CATEGORIES]: '/Categories',
                    [SCREEN.ADD_CATEGORIES]: '/UploadCategories',
                    [SCREEN.SUB_CATEGORIES]: '/SubCategories',
                    [SCREEN.ADD_SUB_CATEGORIES]: '/UploadSubCategories',
                    [SCREEN.CATEGORY_CONTENT]: '/ContentList',
                    [SCREEN.ADD_CATEGORIES_NOTE]: '/UploadContent',
                    [SCREEN.LINK_DETAIL]: '/SocialLinks',
                    [SCREEN.ADD_LINK]: '/UploadLink',
                    [SCREEN.CONSULTATION]: '/Consultations',
                    [SCREEN.ADD_CONSULTATION]: '/UploadConsultation',
                    [SCREEN.REQUEST]: '/Requests',
                    [SCREEN.DETAIL_REQUEST]: '/RequestDetails',
                    [SCREEN.DAILY_STUDY]: '/DailyStudy',
                    [SCREEN.DAILY_DETAIL]: '/UploadDailyStudy',
                    [SCREEN.HOME_SLIDER]: '/HomeSlider',
                    [SCREEN.DETAIL_FOAM]: '/FormDetails',
                    [SCREEN.DETAIL_FOAM_SUBMIT]: '/UploadFields',
                    [SCREEN.POPUP]: '/UploadNewsPopup',
                    [SCREEN.BOOKS]: '/Books',
                    [SCREEN.ADD_BOOK]: '/UploadBook',
                    [SCREEN.NEWS_LETTERS]: '/WeeklyNewsLetters',
                    [SCREEN.ADD_NEWS_LETTERS]: '/UploadNewsletters',
                }
            },
        }}>
            <Stack.Navigator screenOptions={screenOptionStyle}>
                <Stack.Screen name={SCREEN.LOGIN} component={LoginScreen} />

                {/* <Stack.Screen name={SCREEN.SYSTEM_ADMIN} component={SystemAdministrator} /> */}

                <Stack.Screen name={SCREEN.CATEGORIES} component={CategoriesScreen} />
                <Stack.Screen name={SCREEN.ADD_CATEGORIES} component={AddCategoryScreen} />

                <Stack.Screen name={SCREEN.SUB_CATEGORIES} component={SubCategoriesScreen} />
                <Stack.Screen name={SCREEN.ADD_SUB_CATEGORIES} component={AddSubCategoriesScreen} />
                <Stack.Screen name={SCREEN.ADD_CATEGORIES_NOTE} component={AddCategoryNote} />
                <Stack.Screen name={SCREEN.CATEGORY_CONTENT} component={CategoryContentScreen} />

                {/* <Stack.Screen name={SCREEN.LINK} component={LinkScreen} /> */}
                <Stack.Screen name={SCREEN.ADD_LINK} component={AddLinkScreen} />
                <Stack.Screen name={SCREEN.LINK_DETAIL} component={LinkDetailScreen} />

                <Stack.Screen name={SCREEN.CONSULTATION} component={ConsultationScreen} />
                <Stack.Screen name={SCREEN.ADD_CONSULTATION} component={AddConsultationScreen} />

                <Stack.Screen name={SCREEN.REQUEST} component={RequestScreen} />
                <Stack.Screen name={SCREEN.DETAIL_REQUEST} component={DetailRequest} />

                {/* <Stack.Screen name={SCREEN.SETTING} component={SettingScreen} /> */}

                <Stack.Screen name={SCREEN.DAILY_STUDY} component={DailyStudyScreen} />
                <Stack.Screen name={SCREEN.DAILY_DETAIL} component={DailyStudyDetailScreen} />

                <Stack.Screen name={SCREEN.HOME_SLIDER} component={HomeSliderScreen} />

                <Stack.Screen name={SCREEN.DETAIL_FOAM} component={DetailFoamScreen} />
                <Stack.Screen name={SCREEN.DETAIL_FOAM_SUBMIT} component={DetailFoamSubmit} />

                <Stack.Screen name={SCREEN.POPUP} component={PopUpScreen} />
                <Stack.Screen name={SCREEN.BOOKS} component={BooksListScreen} />
                <Stack.Screen name={SCREEN.ADD_BOOK} component={AddBookScreen} />

                <Stack.Screen name={SCREEN.NEWS_LETTERS} component={NewsLettersScreen} />
                <Stack.Screen name={SCREEN.ADD_NEWS_LETTERS} component={AddNewsLettersScreen} />

            </Stack.Navigator>
        </NavigationContainer>
    )
}

export default RootNavigator
