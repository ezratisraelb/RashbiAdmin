import { IMAGES } from '../assets/images'
import { SCREEN } from './enums'
import En from './locals/En'

export const sideBarData = [
    { text: En.categories, image: IMAGES.Categories, routes: [SCREEN.CATEGORIES, SCREEN.ADD_CATEGORIES] },
    { text: En.subCategories, image: IMAGES.Sub_Categorie, routes: [SCREEN.SUB_CATEGORIES, SCREEN.ADD_SUB_CATEGORIES, SCREEN.CATEGORY_CONTENT, SCREEN.ADD_CATEGORIES_NOTE] },
    { text: En.links, image: IMAGES.Link, routes: [SCREEN.LINK_DETAIL, SCREEN.ADD_LINK] },
    { text: En.consultation, image: IMAGES.Consultation, routes: [SCREEN.CONSULTATION, SCREEN.ADD_CONSULTATION] },
    { text: En.requests, image: IMAGES.Requests, routes: [SCREEN.REQUEST, SCREEN.DETAIL_REQUEST] },
    // { text: En.settings, image: IMAGES.Setting, routes: [SCREEN.SETTING] },
    { text: En.dailyStudies, image: IMAGES.DailyStudy, routes: [SCREEN.DAILY_STUDY, SCREEN.DAILY_DETAIL] },
    { text: En.homeSlider, image: IMAGES.HomeSlider, routes: [SCREEN.HOME_SLIDER] },
    { text: En.detailForm, image: IMAGES.DetailFoam, routes: [SCREEN.DETAIL_FOAM, SCREEN.DETAIL_FOAM_SUBMIT] },
    { text: En.popUpNews, image: IMAGES.PopUp, routes: [SCREEN.POPUP] },
    { text: En.books, image: IMAGES.Book, routes: [SCREEN.BOOKS, SCREEN.ADD_BOOK] },
    { text: En.newsletters, image: IMAGES.Book, routes: [SCREEN.NEWS_LETTERS, SCREEN.ADD_NEWS_LETTERS] },
]

export const consultationTypes = {
    FREE: 'Free',
    PAID: 'Paid',
}

export const consultations = [
    { label: En.free, value: consultationTypes.FREE },
    { label: En.paid, value: consultationTypes.PAID },
]
export const timeToReadData = [
    { label: `1 ${En.days}`, value: '1 days' },
    { label: `2 ${En.days}`, value: '2 days' },
    { label: `3 ${En.days}`, value: '3 days' },
    { label: `4 ${En.days}`, value: '4 days' },
    { label: `5 ${En.days}`, value: '5 days' },
    { label: `6 ${En.days}`, value: '6 days' },
    { label: `7 ${En.days}`, value: '7 days' },
]

export const fileTypeData = [
    { label: 'pdf', value: 'pdf' },
    { label: 'text', value: 'text' },
]

export const filedTypes = [
    { label: En.optional, value: 'optional' },
    { label: En.required, value: 'required' },
]