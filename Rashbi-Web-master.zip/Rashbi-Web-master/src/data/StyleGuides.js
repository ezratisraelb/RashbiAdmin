import { Dimensions, StyleSheet } from 'react-native'
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen'

export const WIDTH = Dimensions.get('window').width
export const HEIGHT = Dimensions.get('window').height

export { wp, hp }

export const COLOR = {
    white: '#ffffff',
    black: '#000000',
    black_20: 'rgba(0,0,0,0.5)',
    primary: '#FFEFE0',
    secondary: '#FECAAD',
    lightPrimary: '#FFEFE5',
    lightGrey: '#B5B5B5',
    lightGrey_2: '#D9D9D9',
    grey: '#808080',
    orange: '#D67845',
    darkSecondary: '#FECDB3',
    green: '#03AD00',
    red: '#8C070A',
    lightRed: '#FF281B',
}

export const FONT = {
    PoppinsRegular: 'Poppins-Regular',
    PoppinsBold: 'Poppins-Bold',
    PoppinsExtraBold: 'Poppins-ExtraBold',
    PoppinsLight: 'Poppins-Light',
    PoppinsSemiBold: 'Poppins-SemiBold',
    PoppinsThin: 'Poppins-Thin',
    PoppinsMedium: 'Poppins-Medium',
    PoppinsBlack: 'Poppins-Black',
}

export const TEXT_STYLE = StyleSheet.create({
    titleBold: {
        fontFamily: FONT.bold,
        fontSize: 24,
    },
    titleSemiBold: {
        fontFamily: FONT.semiBold,
        fontSize: 24,
    },
    titleMedium: {
        fontFamily: FONT.medium,
        fontSize: 24,
    },
    smallTitleBold: {
        fontFamily: FONT.bold,
        fontSize: 22,
    },
    smallTitleSemiBold: {
        fontFamily: FONT.semiBold,
        fontSize: 22,
    },
    smallTitleMedium: {
        fontFamily: FONT.medium,
        fontSize: 22,
    },
    bigText: {
        fontFamily: FONT.regular,
        fontSize: 17,
    },
    bigTextSemiBold: {
        fontFamily: FONT.semiBold,
        fontSize: 17,
    },
    bigTextMedium: {
        fontFamily: FONT.medium,
        fontSize: 17,
    },
    bigTextBold: {
        fontFamily: FONT.bold,
        fontSize: 17,
    },
    text: {
        fontFamily: FONT.regular,
        fontSize: 14,
    },
    textSemiBold: {
        fontFamily: FONT.semiBold,
        fontSize: 14,
    },
    textMedium: {
        fontFamily: FONT.medium,
        fontSize: 14,
    },
    textBold: {
        fontFamily: FONT.bold,
        fontSize: 14,
    },
    smallText: {
        fontFamily: FONT.regular,
        fontSize: 12,
    },
    smallTextSemiBold: {
        fontFamily: FONT.semiBold,
        fontSize: 12,
    },
    smallTextMedium: {
        fontFamily: FONT.medium,
        fontSize: 12,
    },
    smallTextBold: {
        fontFamily: FONT.bold,
        fontSize: 12,
    },
})

export const commonStyles = StyleSheet.create({
    horizontalView: {
        alignItems: 'center',
        flexDirection: 'row',
    },
    horizontalView_m1: {
        alignItems: 'center',
        flexDirection: 'row',
        marginVertical: hp(1),
    },
    justifyView: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    justifyView_m1: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginVertical: hp(1),
    },
    justifyView_m2: {
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginVertical: hp(2),
    },
    center: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    shadow_5: {
        elevation: 5,
        shadowColor: COLOR.black,
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
    },
    shadow_3: {
        elevation: 3,
        shadowColor: COLOR.black,
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.22,
        shadowRadius: 2.22,
    },
    shadow_10: {
        elevation: 10,
        shadowColor: COLOR.black,
        shadowOffset: {
            width: 0,
            height: 5,
        },
        shadowOpacity: 0.34,
        shadowRadius: 6.27,
    },
    noPadding: {
        paddingTop: 0,
        paddingLeft: 0,
        paddingRight: 0,
        paddingBottom: 0,
        paddingStart: 0,
        paddingEnd: 0,
    },
    noMargin: {
        marginTop: 0,
        marginLeft: 0,
        marginRight: 0,
        marginBottom: 0,
        marginStart: 0,
        marginEnd: 0,
    },
    whiteButton: {
        height: hp(5.58),
        backgroundColor: COLOR.white,
        borderWidth: 2,
        borderColor: COLOR.orange,
    },
}) 
