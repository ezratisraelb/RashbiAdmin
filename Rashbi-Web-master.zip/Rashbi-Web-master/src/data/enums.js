
export const SCREEN = {
  LOGIN: 'Login',
  SYSTEM_ADMIN: 'SystemAdministrator',
  CATEGORIES: 'Categories',
  ADD_CATEGORIES: 'AddCategoryScreen',
  SUB_CATEGORIES: 'SubCategories',
  CONSULTATION: 'ConsultationScreen',
  DAILY_STUDY: 'DailyStudy',
  DETAIL_FOAM: 'DetailFoamScreen',
  HOME_SLIDER: 'HomeSlider',
  LINK: 'LinkScreen',
  POPUP: 'PopupScreen',
  REQUEST: 'RequestScreen',
  SETTING: 'SettingScreen',
  SUB_CATEGORIES: 'SubCategories',
  ADD_SUB_CATEGORIES: 'AddSubCategories',
  ADD_CATEGORIES_NOTE: 'AddCategoryNote',
  CATEGORY_CONTENT: 'CategoryContentScreen',
  ADD_LINK: 'AddLinkScreen',
  LINK_DETAIL: 'LinkDetailScreen',
  ADD_CONSULTATION: 'AddConsultation',
  DETAIL_REQUEST: 'DetailRequest',
  DAILY_DETAIL: 'UploadDailyStudy',
  DETAIL_FOAM_SUBMIT: 'DetailFoamSubmit',
  BOOKS: 'BooksListScreen',
  ADD_BOOK: 'AddBookScreen',
  NEWS_LETTERS: 'NewsLettersScreen',
  ADD_NEWS_LETTERS: 'AddNewsLettersScreen',
}

export const KEYBOARD_TYPE = {
  DEFAULT: 'default',
  DECIMAL_PAD: 'decimal-pad',
  NUMERIC: 'numeric',
  EMAIL_ADDRESS: 'email-address',
  PHONE_PAD: 'phone-pad',
  URL: 'url',
}

export const FIREBASE_COLLECTION = {
  DAILY_STUDY: 'dailyStudies',
  APP_CONFIG: 'appConfig',
  SOCIAL_LINKS: 'socialLinks',
  CONSULTATION: 'consultation',
  CATEGORIES: 'categories',
  SUB_CATEGORIES: 'subCategories',
  CATEGORY_CONTENT: 'categoryContent',
  REQUEST: 'requests',
  BOOKS: 'books',
  NEWS_LETTERS: 'newsletters',
}

export const FIREBASE_DOCUMENT = {
  HOME_SLIDER: 'homeSlider',
  DETAIL_FORM: 'detailForm',
  POPUP: 'popupMenu',
}

export const FIREBASE_STORAGE = {
  DAILY_STUDIES: 'daily_studies',
  DAILY_STUDIES_PDF: 'daily_studies_pdf',
  SLIDER: 'slider_images',
  SOCIAL_LINKS: 'social_links',
  CONSULTATION: 'consultations',
  CONSULTATION_VIDEOS: 'consultationVideos',
  CATEGORIES: 'categories',
  SUB_CATEGORIES: 'subCategories',
  CATEGORY_CONTENT: 'categoryContent',
  POPUP: 'popupMenu',
  BOOKS: 'books',
  BOOKS_PDF: 'books_pdf',
  NEWS_LETTERS: 'newsletters',
  NEWS_LETTERS_PDF: 'newsletters_pdf',
}
