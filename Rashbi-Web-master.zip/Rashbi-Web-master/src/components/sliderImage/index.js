import SliderImage from './SliderImage'
export default SliderImage