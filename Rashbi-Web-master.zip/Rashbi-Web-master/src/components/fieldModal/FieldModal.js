import { Modal, View, TouchableOpacity, StyleSheet } from 'react-native-web'
import React, { memo, useState } from 'react'
import { COLOR, hp, wp } from '../../data/StyleGuides'
import { Button, Input, Label } from '../reusables'
import En from '../../data/locals/En'
import { IMAGES } from '../../assets/images'

const FieldModal = ({ visible, setVisible, onDonePress }) => {
    const [text, setText] = useState('')

    const onClose = () => {
        setVisible(false)
        setText('')
    }

    const handleDonePress = () => {
        if (text) {
            onDonePress(text)
            onClose()
        } else {
            alert(En.fillDataError)
        }
    }

    return (
        <Modal visible={visible} transparent={true}>
            <TouchableOpacity onPress={() => onClose()} style={styles.backdropStyle} />

            <View style={styles.container}>
                <Label style={styles.textBold}>{En.addField}</Label>
                <View style={styles.inputContainer}>
                    <Label style={styles.textBold}>{En.fieldName}</Label>
                    <Input
                        value={text}
                        onChange={setText}
                        style={styles.inputStyle}
                    />
                </View>
                <Button
                    icon={IMAGES.TrueIcon}
                    text={En.done}
                    containerStyle={styles.buttonContainer}
                    style={styles.button}
                    onPress={handleDonePress}
                />
            </View>

        </Modal>
    )
}

export default memo(FieldModal)

const styles = StyleSheet.create({
    backdropStyle: {
        flex: 1,
        backgroundColor: COLOR.black_20,
    },
    container: {
        height: hp(44),
        alignSelf: 'center',
        width: '40%',
        top: hp('29%'),
        position: 'absolute',
        borderRadius: hp(3),
        backgroundColor: COLOR.white,
        paddingHorizontal: '3%',
        justifyContent: 'space-evenly',
    },
    textBold: {
        fontWeight: '700',
        textAlign: 'right',
    },
    inputContainer: {
        flexDirection: 'row-reverse',
        alignItems: 'center',
    },
    inputStyle: {
        width: wp(25),
        marginEnd: wp(2),
    },
    button: {
        height: hp(6),
        width: '100%',
    },
    buttonContainer: {
        width: wp(13),
        marginTop: hp(2),
    },
})