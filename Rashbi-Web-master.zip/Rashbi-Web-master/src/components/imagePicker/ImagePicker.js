import { Image, StyleSheet } from 'react-native'
import React, { memo } from 'react'
import { openGallery } from '../../utils/Helper'
import { hp, wp, COLOR, TEXT_STYLE, commonStyles } from '../../data/StyleGuides'
import { Label, Pressable } from '../reusables'

const ImagePicker = ({ value, onChange, style, imageStyle, text }) => {

    const handleFileManager = async () => {
        const image = await openGallery()
        onChange(image?.assets[0]?.uri)
    }
    const onRemovePress = () => {
        onChange('')
    }

    return (
        <Pressable style={[styles.container, style]} onPress={() => handleFileManager()}>
            {value ?
                <>
                    <Image source={{ uri: value }} style={[styles.imageStyle, imageStyle]} />
                    <Pressable style={styles.removeButton} onPress={onRemovePress}>
                        <Label style={styles.minusText}>{'-'}</Label>
                    </Pressable>
                </>
                :
                <Label style={{ fontSize: 17, color: COLOR.grey }}>{text}</Label>
            }
        </Pressable>
    )
}

export default memo(ImagePicker)

const styles = StyleSheet.create({
    container: {
        height: hp(35),
        width: wp(30),
        backgroundColor: COLOR.white,
        borderRadius: hp(1.8),
        marginVertical: hp(1),
        ...commonStyles.center,
        ...commonStyles.shadow_3,
        borderWidth: 1,
        borderColor: COLOR.secondary,
    },
    input: {
        flex: 1,
        ...TEXT_STYLE.text,
        textAlign: 'right',
        marginRight: wp(1)
    },
    imageStyle: {
        height: '100%',
        width: '100%',
        borderRadius: hp(1.8),
    },
    removeButton: {
        height: hp(3.5),
        width: hp(3.5),
        ...commonStyles.center,
        borderRadius: hp(3),
        position: 'absolute',
        top: -hp(0.5),
        left: -hp(1),
        zIndex: 1,
        backgroundColor: COLOR.lightRed,
    },
    minusText: {
        fontSize: 30,
        color: COLOR.white,
        marginBottom: hp(1),
    },
})