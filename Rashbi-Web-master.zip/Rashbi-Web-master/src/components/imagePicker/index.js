import ImagePicker from './ImagePicker'
export default ImagePicker