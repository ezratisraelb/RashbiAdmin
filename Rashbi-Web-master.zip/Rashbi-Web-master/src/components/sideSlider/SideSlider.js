import { StyleSheet, Image, View } from 'react-native'
import React, { memo } from 'react'
import { COLOR, hp, commonStyles, wp } from '../../data/StyleGuides'
import { sideBarData } from '../../data/DummyData'
import { Label, Pressable } from '../reusables'
import { useNavigation, useRoute } from '@react-navigation/native'
import { signOut } from 'firebase/auth'
import { IMAGES } from '../../assets/images'
import En from '../../data/locals/En'
import { FIREBASE_AUTH } from '../../../firebaseConfig'
import { SCREEN } from '../../data/enums'
import { handleResetStack } from '../../utils/Helper'

const SideSlider = () => {
  const currentRoute = useRoute()
  const navigation = useNavigation()

  const handleSignOut = () => {
    signOut(FIREBASE_AUTH).then(() => handleResetStack(navigation, SCREEN.LOGIN))
  }

  return (
    <View style={styles.sideView}>

      {sideBarData.map(({ text, image, routes }, index) => {
        const isActive = routes.includes(currentRoute?.name)
        return (
          <Pressable
            style={[styles.itemContainer, isActive && styles.activeStyles]}
            key={index}
            onPress={() => navigation.navigate(routes[0])}
          >
            <Image
              source={image}
              style={[styles.imageStyle, isActive && styles.activeImage]}
              resizeMode='contain'
            />
            <Label style={[isActive ? styles.activeText : styles.textStyle]}>{text}</Label>
          </Pressable>
        )
      })}

      <Pressable
        style={styles.logoutButton}
        onPress={() => handleSignOut()}
      >
        <Image
          source={IMAGES.Logout}
          style={[styles.imageStyle]}
          resizeMode='contain'
        />
        <Label style={styles.textStyle}>{En.logOut}</Label>
      </Pressable>

    </View>
  )
}

export default memo(SideSlider)

const styles = StyleSheet.create({
  sideView: {
    height: '100%',
    width: '17%',
    backgroundColor: COLOR.secondary,
  },
  itemContainer: {
    height: hp(6.5),
    ...commonStyles.horizontalView,
    flexDirection: 'row-reverse',
    paddingHorizontal: '5%',
  },
  logoutButton: {
    ...commonStyles.horizontalView,
    paddingVertical: hp(0.5),
    flexDirection: 'row-reverse',
    marginHorizontal: '5%',
    position: 'absolute',
    bottom: hp(3),
    right: 0,
  },
  logOutImage: {
    height: hp(3),
    width: hp(3),
    marginStart: wp(1),
  },
  textStyle: {
    fontSize: 17,
    fontWeight: '500',
  },
  imageStyle: {
    height: hp(3),
    width: hp(3),
    marginStart: wp(1),
  },
  activeImage: {
    tintColor: COLOR.secondary,
  },
  activeStyles: {
    backgroundColor: COLOR.black,
  },
  activeText: {
    fontSize: 17,
    fontWeight: '500',
    color: COLOR.secondary,
  },
})