import { StyleSheet, View } from 'react-native'
import React, { memo } from 'react'
import { COLOR, hp } from '../../data/StyleGuides'
import { Label } from '../reusables'
import En from '../../data/locals/En'
import PopupModal from '../popupModal'
import { consultationTypes } from '../../data/DummyData'

const ConsultationView = ({ number, item, firstHeading, secondHeading, onFirstPress, onSecondPress }) => {
    const { fileName, fileType } = item
    const isPaid = fileType === consultationTypes.PAID
    return (
        <View style={styles.container}>
            <View style={styles.popUpContainer}>
                <PopupModal
                    firstHeading={firstHeading}
                    secondHeading={secondHeading}
                    onFirstPress={() => onFirstPress()}
                    onSecondPress={() => onSecondPress()}
                />
            </View>
            {isPaid ?
                <Label style={styles.redText}>{En.paid}</Label>
                :
                <Label style={styles.greenText}>{En.free}</Label>
            }

            <Label style={styles.text}>{fileName}</Label>

            <Label style={styles.blackBold}>.{number}</Label>
        </View>
    )
}

export default memo(ConsultationView)

const styles = StyleSheet.create({
    container: {
        height: hp(7),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.white,
        borderRadius: hp(2),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: COLOR.secondary,
    },
    popUpContainer: {
        minWidth: '4%', alignItems: 'center',
    },
    greenText: {
        fontWeight: '700',
        width: '40%',
        color: COLOR.green,
        textAlign: 'center',
    },
    redText: {
        fontWeight: '700',
        width: '40%',
        color: COLOR.red,
        textAlign: 'center',
    },
    blackBold: {
        minWidth: '7%',
        fontWeight: '700',
        textAlign: 'right',
    },
    text: {
        width: '40%',
        fontWeight: '700',
        textAlign: 'center',
    },
})