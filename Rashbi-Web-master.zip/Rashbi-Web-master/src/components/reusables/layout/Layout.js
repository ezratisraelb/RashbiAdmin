import { StyleSheet, View, Image, ImageBackground } from 'react-native'
import React, { memo } from 'react'
import { COLOR, hp, commonStyles, TEXT_STYLE } from '../../../data/StyleGuides'
import Label from '../label'
import En from '../../../data/locals/En'
import { IMAGES } from '../../../assets/images'
import SideSlider from '../../sideSlider'

const Layout = ({ children, title }) => {
    return (
        <View style={styles.mainContainer}>

            <View style={styles.header}>
                <Label style={{ ...TEXT_STYLE.bigTextBold, fontWeight: '700', marginLeft: '35%' }}>{En.systemAdmin}</Label>
                <View style={commonStyles.horizontalView}>
                    <Label style={{ ...TEXT_STYLE.bigTextBold, fontWeight: '700' }}>{En.rashbi}</Label>
                    <Image source={IMAGES.Rashbi} style={styles.imageContainer} />
                </View>
            </View>

            <View style={styles.remainingContainer}>
                <SideSlider />
                <View style={styles.childrenContainer}>
                    <Label style={styles.childTitle}>{title}</Label>
                    <View style={styles.mainView}>
                        <ImageBackground source={IMAGES.ScreenBackGround} style={styles.background}>
                            {children}
                        </ImageBackground>
                    </View>
                </View>
            </View>

        </View>
    )
}

export default memo(Layout)

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        height: '100%',
        width: '100%',
    },
    header: {
        backgroundColor: COLOR.secondary,
        height: '12%',
        width: '100%',
        paddingHorizontal: '5%',
        ...commonStyles.justifyView,
    },
    imageContainer: {
        height: hp(11),
        width: hp(11),
    },
    childTitle: {
        paddingVertical: '1%',
        paddingRight: '3%',
        fontWeight: '700',
        textAlign: 'right',
    },
    remainingContainer: {
        flex: 1,
        flexDirection: 'row-reverse',
    },
    childrenContainer: {
        flex: 1,
        backgroundColor: COLOR.primary,
    },
    background: {
        height: '100%',
        width: '100%',
    },
    mainView: {
        marginHorizontal: '5%',
        marginBottom: hp(4),
        flex: 1,
        borderRadius: hp(3),
        borderWidth: 1,
        borderColor: COLOR.secondary,
    }
})