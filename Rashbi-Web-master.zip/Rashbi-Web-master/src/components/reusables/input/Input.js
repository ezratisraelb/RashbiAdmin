import { StyleSheet, View, Image } from 'react-native'
import React, { memo } from 'react'
import { COLOR, TEXT_STYLE, commonStyles, hp, wp } from '../../../data/StyleGuides'
import { TextInput } from 'react-native-web'

const Input = (props) => {
    const { placeholder, icon, value, onChange, style, keyboard, isPassword, multiline, limit, imageStyle } = props
    return (
        <View style={[styles.container, style]}>
            <TextInput
                placeholder={placeholder}
                placeholderTextColor={COLOR.grey}
                value={value}
                onChangeText={x => onChange && onChange(x)}
                style={[styles.input, multiline && { textAlignVertical: 'top', outlinecolor: 'orange', paddingVertical: '1.5%' }]}
                keyboardType={keyboard}
                multiline={multiline}
                maxLength={limit}
                secureTextEntry={isPassword}
            />
            {
                icon && <Image resizeMode='center' style={[styles.image, imageStyle]} source={icon} contain />
            }
        </View>
    )
}

export default memo(Input)

const styles = StyleSheet.create({
    container: {
        height: hp(6.6),
        width: '100%',
        borderRadius: hp(1.8),
        marginVertical: hp(1),
        backgroundColor: COLOR.white,
        ...commonStyles.horizontalView,
        ...commonStyles.shadow_3,
        borderWidth: 1,
        borderColor: COLOR.secondary,
        overflow: 'hidden',
        paddingHorizontal: wp(1),
    },
    input: {
        height: '100%',
        width: '100%',
        ...TEXT_STYLE.text,
        textAlign: 'right',
        borderWidth: 0,
        outlineColor: 'rgba(0,0,0,0)', outlineOffset: 0, outlineStyle: 'none',
        outlineWidth: 0, backgroundColor: 'white'

    },
    image: {
        height: hp(2.2),
        width: hp(3.2),
        marginLeft: wp(1),
    }
})