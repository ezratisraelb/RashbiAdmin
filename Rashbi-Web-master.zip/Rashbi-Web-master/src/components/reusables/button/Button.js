import { StyleSheet, Text, TouchableOpacity, Image, ActivityIndicator } from 'react-native'
import React, { memo } from 'react'
import { LinearGradient } from 'expo-linear-gradient'
import { COLOR, wp, TEXT_STYLE, hp, commonStyles } from '../../../data/StyleGuides'

const Button = (props) => {
  const {
    text,
    style,
    containerStyle,
    textStyle,
    onPress,
    icon,
    imgStyle,
    gradient = true,
    buttonColor,
    isLoading
  } = props
  let buttonColors = gradient ? [COLOR.secondary, COLOR.primary] : [buttonColor, buttonColor]
  return (
    <TouchableOpacity onPress={onPress} style={[styles.container, containerStyle]}  activeOpacity={0.85}>
      <LinearGradient
        style={[styles.button, style]}
        colors={buttonColors}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
      >
        <Text allowFontScaling={false} style={[styles.buttonTexts, textStyle]}>
          {isLoading ?
            <ActivityIndicator color={COLOR.white} size={'small'} />
            :
            text
          }</Text>
        {icon && (
          <Image style={[imgStyle ? imgStyle : styles.iconStyle]} source={icon} resizeMode='contain' />
        )}
      </LinearGradient>
    </TouchableOpacity>
  )
}

export default memo(Button)

const styles = StyleSheet.create({
  container: {
    marginVertical: hp(1),
  },
  iconStyle: {
    height: 15,
    width: 15,
    marginLeft: wp(2),
  },
  buttonTexts: {
    ...TEXT_STYLE.textBold,
    fontWeight: '700'

  },
  button: {
    height: hp(8.5),
    padding: 20,
    width: '50%',
    borderRadius: hp(5),
    borderWidth: 0.4,
    borderColor: COLOR.lightGrey,
    alignSelf: 'center',
    ...commonStyles.horizontalView,
    ...commonStyles.center,
  },
})
