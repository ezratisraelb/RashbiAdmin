import { StyleSheet, Text } from 'react-native'
import React, { memo } from 'react'
import { COLOR, TEXT_STYLE } from '../../../data/StyleGuides'

const Label = ({ children, style, color }) => {
    return (
        <Text style={[styles.textStyle, { color: color || COLOR.black }, style]}>{children}</Text>
    )
}

export default memo(Label)

const styles = StyleSheet.create({
    textStyle: {
        ...TEXT_STYLE.text,
    },
})