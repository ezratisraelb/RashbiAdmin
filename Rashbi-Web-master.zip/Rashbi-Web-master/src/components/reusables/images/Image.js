import React, { memo } from 'react'
import { StyleSheet } from 'react-native'
import ExpoFastImage from 'expo-fast-image'
import { hp } from '../../../data/StyleGuides'

const Image = ({ src, style, contain, url }) => {
    return (
        <ExpoFastImage
            source={src ? src : { uri: url }}
            style={[styles.image, style]}
            resizeMode={contain ?
                ExpoFastImage.resizeMode.contain :
                ExpoFastImage.resizeMode.cover
            }
        />
    )
}

export default memo(Image)

const styles = StyleSheet.create({
    image: {
        height: hp(5),
        width: hp(5),
    },
})