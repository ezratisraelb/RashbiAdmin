import DocumentPicker from './DocumentPicker'
export default DocumentPicker