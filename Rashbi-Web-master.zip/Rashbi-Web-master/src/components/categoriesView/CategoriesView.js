import React, { memo } from 'react'
import { StyleSheet, View } from 'react-native'
import { COLOR, hp } from '../../data/StyleGuides'
import PopupModal from '../popupModal'
import { Label } from '../reusables'

const CategoriesView = ({ number, text, firstHeading, onFirstPress, onSecondPress, secondHeading, onThirdPress, thirdHeading }) => {

    return (
        <View style={styles.container}>
            <PopupModal
                firstHeading={firstHeading}
                secondHeading={secondHeading}
                thirdHeading={thirdHeading}
                onFirstPress={() => onFirstPress()}
                onSecondPress={() => onSecondPress()}
                onThirdPress={() => onThirdPress()}
            />

            <Label style={{ fontWeight: '700' }}>{text}</Label>
            <Label style={{ fontWeight: '700' }}>.{number}</Label>
        </View>
    )
}

export default memo(CategoriesView)

const styles = StyleSheet.create({
    container: {
        height: hp(7),
        width: '90%',
        marginHorizontal: '5%',
        backgroundColor: COLOR.white,
        borderRadius: hp(2),
        paddingHorizontal: '3%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: '0.5%',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: COLOR.secondary
    }
})