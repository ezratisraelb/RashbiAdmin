import CategoriesView from './CategoriesView'
export default CategoriesView