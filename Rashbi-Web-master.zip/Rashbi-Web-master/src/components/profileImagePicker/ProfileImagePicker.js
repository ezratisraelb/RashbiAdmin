import { Image, StyleSheet, View } from 'react-native'
import React, { memo } from 'react'
import { openGallery } from '../../utils/Helper'
import { hp, wp, COLOR, TEXT_STYLE, commonStyles } from '../../data/StyleGuides'
import { Button } from '../reusables'
import { IMAGES } from '../../assets/images'

const ProfileImagePicker = ({ value, onChange, style, imageStyle, buttonStyle, buttonText }) => {

    const handleFileManager = async () => {
        const image = await openGallery()
        onChange(image?.assets[0]?.uri)
    }

    return (
        <View>

            <View style={[styles.container, style]}>
                {value ?
                    <Image source={{ uri: value }} style={[styles.imageStyle, imageStyle]} />
                    :
                    <Image source={IMAGES.ProfileImage} style={{ height: hp(24), width: wp(10) }} />
                }
            </View>
            <Button text={buttonText} style={buttonStyle} onPress={() => handleFileManager()} />
        </View>
    )
}

export default memo(ProfileImagePicker)

const styles = StyleSheet.create({
    container: {
        height: hp(35),
        width: wp(30),
        backgroundColor: COLOR.white,
        borderRadius: hp(1.8),
        // paddingHorizontal: '3%',
        marginVertical: hp(1),
        ...commonStyles.center,
        ...commonStyles.shadow_3,
        borderWidth: 1,
        borderColor: COLOR.secondary,
    },
    input: {
        flex: 1,
        ...TEXT_STYLE.text,
        textAlign: 'right',
        marginRight: wp(1)
    },
    imageStyle: {
        height: hp(25),
        width: wp(10),
        borderRadius: hp(1.8),
    },
})