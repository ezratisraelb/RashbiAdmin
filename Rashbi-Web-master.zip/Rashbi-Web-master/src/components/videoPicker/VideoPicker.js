import { StyleSheet, View } from 'react-native'
import React, { memo } from 'react'
import { Video, ResizeMode } from 'expo-av'
import { Pressable, Label } from '../reusables'
import { hp, COLOR, wp, commonStyles } from '../../data/StyleGuides'
import { pickVideo } from '../../utils/Helper'
import En from '../../data/locals/En'

const VideoPicker = ({ value, onChange, style }) => {

    const handleFileManager = async () => {
        const video = await pickVideo()
        onChange(video?.assets[0]?.uri)
    }

    const onRemovePress = () => {
        onChange('')
    }

    return (
        <>
            {value ?
                <View>
                    <Video
                        useNativeControls
                        resizeMode={ResizeMode.COVER}
                        source={{ uri: value }}
                        positionMillis={180000}
                        shouldPlay={false}
                        style={[styles.container, style]}
                        scaleX={10}
                        scaleY={10}
                        videoStyle={styles.videoStyle}
                    />
                    <Pressable style={styles.removeButton} onPress={onRemovePress}>
                        <Label style={styles.minusText}>{'-'}</Label>
                    </Pressable>
                </View>
                :
                <Pressable style={[styles.container, style]} onPress={() => handleFileManager()}>
                    <Label style={{ fontSize: 17, color: COLOR.grey }}>{`+ ${En.addVideo}`}</Label>
                </Pressable>
            }
        </>
    )
}

export default memo(VideoPicker)

const styles = StyleSheet.create({
    container: {
        height: hp(23),
        width: wp(18),
        backgroundColor: COLOR.white,
        borderRadius: hp(1.8),
        marginVertical: hp(1),
        ...commonStyles.center,
        ...commonStyles.shadow_3,
        borderWidth: 1,
        borderColor: COLOR.secondary,
    },
    videoStyle: {
        height: '100%',
        width: '100%',
    },
    imageStyle: {
        height: '100%',
        width: '100%',
        borderRadius: hp(1.8),
    },
    removeButton: {
        height: hp(3.5),
        width: hp(3.5),
        ...commonStyles.center,
        borderRadius: hp(3),
        position: 'absolute',
        top: -hp(0.5),
        left: -hp(1),
        zIndex: 1,
        backgroundColor: COLOR.lightRed,
    },
    minusText: {
        fontSize: 30,
        color: COLOR.white,
        marginBottom: hp(1.2),
    },
})