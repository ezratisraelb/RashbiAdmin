import { View } from 'react-native-web'
import RootNavigator from './src/navigation/RootNavigation'
import { MenuProvider } from 'react-native-popup-menu'

const App = () => {
  return (
    <MenuProvider>

      <View style={{ flex: 1 }}>
        <RootNavigator />
      </View>
    </MenuProvider>
  )
}

export default App
